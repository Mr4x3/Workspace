
EMAIL = {
    'header': """<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>DemystifyingEmailDesign</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
</head>
<body style="margin:0;padding:0;padding-top: 15px; padding-bottom: 15px;background: #f1f1f1;" >
<table width="600" class="mi-all" align="center" cellspacing="0" cellpadding="0" border="0" style="background:#fff;border-spacing:0;border:0;margin:0 auto;padding:0;min-width:600px;border:1px solid #cccccc;font-size:14px;" >
<tbody>

<tr align="left" style="border-collapse: collapse;border-spacing: 0;border: 0;  ">
        <td>
            <table cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;border-spacing: 0;border: 0; min-width:600px;">
                <tbody>
                    <tr style="border-collapse: collapse;border-spacing: 0;border: 0;">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="http://www.supplified.com" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="47" src="https://mi-images-production.s3.amazonaws.com/crops/6632420/2fab3f094d5094044527f339a3e288cc-original.jpg?1447843188" style="display:block; line-height:0px; border:0; " width="169">

    </a>

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

            <img height="47" src="https://mi-images-production.s3.amazonaws.com/crops/6632424/bea5dd21359c9143a1a70c76d65da657-original.jpg?1447843193" style="display:block; line-height:0px; border:0; " width="241">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="https://www.facebook.com/supplified" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="47" src="https://mi-images-production.s3.amazonaws.com/crops/6632421/13a330db43a7d7bda43739debce94510-original.jpg?1447843192" style="display:block; line-height:0px; border:0; " width="36">

    </a>

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="https://www.linkedin.com/company/supplified-com" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="47" src="https://mi-images-production.s3.amazonaws.com/crops/6632425/3ec4f06217c7327172273442636288d3-original.jpg?1447843194" style="display:block; line-height:0px; border:0; " width="34">

    </a>

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="tel:919999999995" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="47" src="https://mi-images-production.s3.amazonaws.com/crops/6632426/50a4a6abc856340d6d23f58444f5c42d-original.jpg?1447843194" style="display:block; line-height:0px; border:0; " width="120">
    </a>

</td>

                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
<tr align="left" style="border-collapse: collapse;border-spacing: 0;border: 0;  ">
        <td>
            <table cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;border-spacing: 0;border: 0; min-width:600px;">
                <tbody>
                    <tr style="border-collapse: collapse;border-spacing: 0;border: 0;">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633672/1f3bfce236c45ddb214e45a0d9da9177-original.jpg?1447846444" style="display:block; line-height:0px; border:0; " width="33">

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="http://www.supplified.com/home/building-material/277" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633669/7e16fbd98cf9cb5bb63d36c5aaca23e7-original.jpg?1447846442" style="display:block; line-height:0px; border:0; " width="123">

    </a>

</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="http://www.supplified.com/home/carpentry/203" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633684/0f0e9992bd7dd4a658fc670ca2209481-original.jpg?1447846454" style="display:block; line-height:0px; border:0; " width="74">

    </a>

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="http://www.supplified.com/home/electrical/166" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633695/5a69b03afc0bbb2e0e9c0987b6902727-original.jpg?1447846458" style="display:block; line-height:0px; border:0; " width="73">

    </a>

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="http://www.supplified.com/home/facility-management/270" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633702/438ddbfa03b559d39f1bec7ff2ef00ed-original.jpg?1447846464" style="display:block; line-height:0px; border:0; " width="143">

    </a>

</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

    <a href="http://www.supplified.com/home/flooring-&amp;-wall/179" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633710/9aad37028dde37a6d2e88ef1beac201d-original.jpg?1447846475" style="display:block; line-height:0px; border:0; " width="112">

    </a>

</td>

                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

            <img height="27" src="https://mi-images-production.s3.amazonaws.com/crops/6633707/1a1e70a8f8d91d8d5653c303f81b5ddc-original.jpg?1447846473" style="display:block; line-height:0px; border:0; " width="42">

</td>

                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
<tr align="left" style="border-collapse: collapse;border-spacing: 0;border: 0;  ">
        <td>
            <table cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;border-spacing: 0;border: 0; min-width:600px;">
                <tbody>
                    <tr style="border-collapse: collapse;border-spacing: 0;border: 0;">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

            <img height="21" src="https://mi-images-production.s3.amazonaws.com/crops/6633638/91a67e2f64a2ecdb2f9fd7184cf8f34c-original.jpg?1447846436" style="display:block; line-height:0px; border:0; " width="600">

</td>

                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr align="left" style="border-collapse: collapse;border-spacing: 0;border: 0;  ">
        <td style="padding: 0 20px;">""",

    'footer': """</td></tr><tr align="left" style="background:#ededed;border-collapse: collapse;border-spacing: 0;border: 0;  ">
        <td>
            <table cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;border-spacing: 0;border: 0; min-width:600px;">
                <tbody>
                    <tr style="border-collapse: collapse;border-spacing: 0;border: 0;">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632441/2fb6bd9f71a435ad456a532a56a54e7f-original.jpg?1447843241" style="display:block; line-height:0px; border:0; " width="37">
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/building-material/277" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632444/501968380ef890ccacbc566e0fc859a0-original.jpg?1447843242" style="display:block; line-height:0px; border:0; " width="126">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/carpentry/203" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632447/02631ca9d6902e94626274a2583cd8c1-original.jpg?1447843246" style="display:block; line-height:0px; border:0; " width="74">
    </a>
</td>
                           <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/electrical/166" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632445/485a931a880cec7c6844b6cc76b8ce39-original.jpg?1447843246" style="display:block; line-height:0px; border:0; " width="75">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/facility-management/270" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632450/08b0ba4335395e68a861b66e3099da38-original.jpg?1447843251" style="display:block; line-height:0px; border:0; " width="141">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/flooring-&amp;-wall/179" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632452/fe56fb913e4f714e1ff187ee225877a6-original.jpg?1447843253" style="display:block; line-height:0px; border:0; " width="114">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
            <img height="34" src="https://mi-images-production.s3.amazonaws.com/crops/6632451/78ef76ac7bd0553b9546f5381e15b531-original.jpg?1447843252" style="display:block; line-height:0px; border:0; " width="33">
</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr align="left" style="border-collapse: collapse;border-spacing: 0;border: 0;background:#ededed;">
        <td>
            <table cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;border-spacing: 0;border: 0; min-width:600px;">
                <tbody>
                    <tr style="border-collapse: collapse;border-spacing: 0;border: 0;">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">

            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632456/cb0af163c110210c1b59262bf89810b1-original.jpg?1447843258" style="display:block; line-height:0px; border:0; " width="52">
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/kitchen/188" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632455/8391434b9c1ba8b3365196a3fa93ba06-original.jpg?1447843258" style="display:block; line-height:0px; border:0; " width="71">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/landscaping/234" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632459/4bfcc4f6455c3797ba1c831d735bf0c6-original.jpg?1447843260" style="display:block; line-height:0px; border:0; " width="92">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/paints-&amp;-chemicals/250" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632461/b0a3082bd9ed16ce539197bc7342f866-original.jpg?1447843265" style="display:block; line-height:0px; border:0; " width="133">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/plumbing/4" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632463/b8e173b07f42d8dedd40c86f152e493f-original.jpg?1447843268" style="display:block; line-height:0px; border:0; " width="74">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
    <a href="http://www.supplified.com/home/safety-&amp;-security/147" target="_blank" style="display:block; border:none;  text-decoration:none; font-size:10px; padding:0; margin:0; border:none;">
            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632465/4cf2458215166be43eeeceb4c7b61a4a-original.jpg?1447843271" style="display:block; line-height:0px; border:0; " width="124">
    </a>
</td>
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
            <img height="26" src="https://mi-images-production.s3.amazonaws.com/crops/6632466/6a38e1d566715d4f89ebdd997ae570b6-original.jpg?1447843271" style="display:block; line-height:0px; border:0; " width="54">
</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr align="left" style="border-collapse: collapse;border-spacing: 0;border: 0;background:#ededed;">
        <td>
            <table cellspacing="0" cellpadding="0" border="0" style="border-collapse: collapse;border-spacing: 0;border: 0; min-width:600px;">
                <tbody>
                    <tr style="border-collapse: collapse;border-spacing: 0;border: 0;">
                            <td align="left" valign="top" style="  line-height: 0px; mso-line-height-rule:exactly;">
            <img height="128" src="https://mi-images-production.s3.amazonaws.com/crops/6632454/ca88cc082b51947888ca64758ba09184-original.jpg?1447843257" style="display:block; line-height:0px; border:0; " width="600">
</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr></tbody></table>"""

}
