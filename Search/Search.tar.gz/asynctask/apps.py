from django.apps import AppConfig


class AsynctaskConfig(AppConfig):
    name = 'asynctask'
